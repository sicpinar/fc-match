export async function handler(event, context){
  return { statusCode: 200, body: JSON.stringify({ ok: true, note: "Stub function - implement later" }) }
}