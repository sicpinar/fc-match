# FC Match

Install: npm i
Run: npm run dev
Build: npm run build
